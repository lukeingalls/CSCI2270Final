
#include "Player.hpp"
#include<iostream>
#include<string>
using namespace std;
void menu();
void jokic();

int main() {
	percentile_scoring ps;
	ps.readinfile("train_data.csv");
	ps.sort_basic_arrays();
	ps.print_top_n_points(10);
	ps.rank_top();
	ps.print_top_n_aggregate(60);
	ps.read_draft_file("drafts.csv");
	ps.write_to_final_csv();
	// ps.print_all_players();
	// ps.rtable().printTable(); //This is how to print all players
	bool tf = 1;
	string menuChoice, n;

	cout << "-----Welcome to the NBA Draft predictor-----" << endl;
	menu();
	getline(cin,menuChoice);
	do
	{
		//find some way to check if their input is valid
		// if(menuChoice[0] > 'Z')
		// {
		// 	cout << "Enter valid menu choice, make sure your input is capitalized" << endl;
		// 	menu();
		// 	tf = true;
		// 	break;
		// }
		switch(menuChoice[0])
		{

			case 'A':
			{
				cout << "How many players would you like to display?" << endl;
				getline(cin, n);
				ps.print_top_n_games(stoi(n));
				tf = true;
				break;
			}
			case 'B':
			{
				cout << "How many players would you like to display?" << endl;
				getline(cin, n);
				ps.print_top_n_minutes(stoi(n));
				tf = true;
				break;
			}
			case 'C':
			{
				cout << "How many players would you like to display?" << endl;
				getline(cin, n);
				ps.print_top_n_points(stoi(n));
				tf = true;
				break;
			}
			case 'D':
			{
				cout << "How many players would you like to display?" << endl;
				getline(cin, n);
				ps.print_top_n_rebounds(stoi(n));
				tf = true;
				break;
			}
			case 'E':
			{
				cout << "How many players would you like to display?" << endl;
				getline(cin, n);
				ps.print_top_n_assists(stoi(n));
				tf = true;
				break;
			}
			case 'F':
			{
				cout << "How many players would you like to display?" << endl;
				getline(cin, n);
				ps.print_top_n_blocks(stoi(n));
				tf = true;
				break;
			}
			case 'G':
			{
				cout << "How many players would you like to display?" << endl;
				getline(cin, n);
				ps.print_top_n_steals(stoi(n));
				tf = true;
				break;
			}
			case 'H':
			{
				cout << "How many players would you like to display?" << endl;
				getline(cin, n);
				ps.print_top_n_turnovers(stoi(n));
				tf = true;
				break;
			}
			case 'I':
			{
				cout << "How many players would you like to display?" << endl;
				getline(cin, n);
				ps.print_top_n_fouls(stoi(n));
				tf = true;
				break;
			}
			case 'J':
			{
				ps.rtable().printTable();
				tf = true;
				break;
			}
			case 'K':
			{
				string w1,w2,w3,w4,w5,w6,w7,w8,w9;
				cout << "How much would you like to weight number of games played" << endl;
				getline(cin, w1);
				cout << "How much would you like to weight number of minutes played" << endl;
				getline(cin, w2);
				cout << "How much would you like to weight average points per game" << endl;
				getline(cin, w3);
				cout << "How much would you like to weight average rebounds per game" << endl;
				getline(cin,w4);
				cout << "How much would you like to weight average assists per game" << endl;
				getline(cin,w5);
				cout << "How much would you like to weight average steals per game" << endl;
				getline(cin,w6);
				cout << "How much would you like to weight average blocks per game" << endl;
				getline(cin,w7);
				cout << "How much would you like to weight average turnovers per game" << endl;
				getline(cin,w8);
				cout << "How much would you like to weight average fouls per game" << endl;
				getline(cin,w9);
				ps.update_ranks(stof(w1),stof(w2),stof(w3),stof(w4),stof(w5),stof(w6),stof(w7),stof(w8),stof(w9));
				cout << "Enter how many top players would you like to display with the new weights "<< endl;
				getline(cin, n);
				ps.print_top_n_aggregate(stoi(n));
				tf = true;
				break;
			}
			case'Z':
			{
				cout << "Exiting" << endl;
				// call desctructor
				tf = false;
				jokic();
				break;
			}
		}
		if(tf == false)
		{
			break;
		}
		menu();
		getline(cin,menuChoice);

	}while(menuChoice[0] != 'Z' || tf == true);

}

void menu()
{
	cout << endl;
	cout <<"A. Display top N players for number of games played " << endl;
	cout <<"B. Display top N players for minutes played " << endl;
	cout <<"C. Display top N players for points per game " << endl;
	cout <<"D. Display top N players for rebounds per game " << endl;
	cout <<"E. Display top N players for assists per game " << endl;
	cout <<"F. Display top N players for steals per game " << endl;
	cout <<"G. Display top N players for blocks per game " << endl;
	cout <<"H. Display top N players for turnovers per game " << endl;
	cout <<"I. Display top N players for fouls per game " << endl;
	cout <<"J. Display ALL players " << endl;
	cout <<"K. Customize each statistics weight " << endl;

}

void jokic()
{
	cout <<R"( .................................``     ``......``      ..`` `` ``                                                                 ``` `     `                                                     ` `..``` `````.`  `....`` ``         `..............````
                ++++++++++++++++++++++++++++///++:.`````-/++++++/-.`````+o.:`-.`::````````.```....```````...............`....................-/ooshsdhydyos:/::-................................................```-`/y+/-.`:.-..o:``-+ooo:-.-.`````````/oo+ooooooo++++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::````````.```......```````............``..............-/osdhmmmmmmmmmmmmmmdmdddyso//-...........................................``:`/yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+ooooooo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::````````.```......`````````````````````.........-/osddmmmmmmNNNNNNNNNNNNmmmmmmmmmmmdy+/........................................``:`/yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+ooooooo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::````````.```......`````````````````````......:oydmmmmNNNNNNNNNNNNNNNNNNNNNNmmmmmmmmmmmmh+-.....................................``:`/yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+ooooooo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::````````.```......`````````````````````...-+smmmmNNmNNNNNNNNNNNNNNNNNNNNNNNNNNNNmmmmmmmmmdy+-..................................``:`/yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::````````.```............................-odmmmNNNmNNNmmmmNNNNNNmNNmNmNNNNNNNNmmNNmmNmmmmmmmdho:................................``:`/yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::````````.```.........................`:odmmmNmNmmmmmmmmmmmmmmmmmmmmmmmmmmNmNNmmNmmmmmNNmmmmmddh+-..............................``:`/yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::````````.```.........................+dmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmNNNmmmmmmmmmmmmmmmddhyo-............................``:`/yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::````````.```......................`/hmmmmmmmmmmmddddmmmddmmddddddddddmmmmmmmmmmmmmmmmmmmmmmmmmmmddy/-..........................``:`/yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::````````.```....................../dmmmmmmmmmmmdddddddmddddhhddhhhhhhhdhddmmmmmmmmmmmmmmmmmmmmmmmmddy/........................```:`/yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::````````.```````````````````````:sdmmmmmmmmmdddddhhhdhddddhhyhhdhhhhhhhhddddmmmmmmddddddmmmmmmmmmmmddho.......................```:`/yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::````````.````..............````:hmdmmmmmmddddhhhhhhhyhhhddhyyyyyysyyhyyyhhhdddmmddddddmmdddmmmmmmmmmdhh/......................```:`/yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::````````..``````.....```````.`:hdddmmmmddddddhdhdddhyhyyhhhhyyyysysyyhyhhhhdddmmddddddddddddmmmmmmmmddho...``````````````````````:`/yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::````````....................``sdhdddddhhhhdhhhhdddhhhyyyyyhyyyysssyyyyhddddhhddddddhhdhdhhddddddmmmmdddy-..``````````````````````:`/yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::`````````````````````````````.shhddhhhyyyyyhhhhdddhhyssyyhysssssssyyyhyhhhhhhhhdddhhhhhhhhyyhhdddmmmdddds.......................`:`/yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::````````````````````````````.+hhhddhyysssssssyyyyhhhhyyyyyyssyysssyyyyhhhhhhhhhyhhyyyyyhyyyyyyyhddddddddh+......................`:`/yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::````````````````````````````-yhhhhhyyssooo++o+oossyyyyyyyysssssosossyyyyyhyhsyyysssssssssssssssyhhdddddddy+.....................`:`/yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::```````.....................:yyyyyyysso+++//////++++++oooooo+++++/++osssoss++++++++ooo+o+oooooosyyhhdhddhhs.....................`:`/yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::```````-/:////////::::::::::ohyyyyyssso+/////////:::::::::::-:::::::/+///////:::://///++++++oooosyyhhhhhhh+`....................`:`/yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::```````...............::::::ohhhhhyyss++////////::::::-----------:--:::::::::::::::////////+++ooosyhhhhyyys.....................`:`/yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``````````````````````./////shhdhhyyyso+///////:::::::---------------::::::::::::::////////+++ooosyyyyysoyy-.....................:`/yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::```````````````````````./////hhhhyyyso++///////::::::::-----------------:::::::::://////////+++ossyyssoooyhy/++++++++++++++++++++/`/yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::````````````````````````.////shhhyyssso+//////:::::::::::::::::--------:::::::::////////////+++oosyss+//+ss+/////////////////////-./yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``..````````````````````.::::+hhhhyssso++/////::::::/:/::::::::::::::::::::::://////////////+++oosyyo//:+oo/::--------------------./yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``./`.`````````````````:+++++ohhhhyssso+////::////::::::::::::::::::::::::::::::::::////////++++ossss/://oo//-...................../yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+ooooooo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+`--.``````````````-oooooo+hhhhyyso++////:::/:::::::--------::::::::::::::::::::::///////++++oooss+///+/::....................../yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+ooooooo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+`---..````````````/++++++/yhhyys++++////::::::::::-------------------------:-::::::://///+++++++++:/+//:-......................+yo/-.`:.--.o:``-+ooo:-.-.`````````/oo+ooooooo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+`----:++++++++++++++++++++shhyyo+////////:::::::::---------------------------::::::://////++/:/::+//////:----/////////////////+syo/-.`:.--.o:``-+ooo:-.-.`````````/oo+ooooooo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+`-----::::::::::::::::+o++ohhhyo////////:::::::::-----------------:-::-::::://++oooo++oo+/++/:::-:::///++:oo/yyyyyyyyyyyyyyyyyyyyo/-.`:.--.o:``-+ooo:-.-.`````````/oo+ooooooo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+`---------------------/+o+oyhhyo/////////++/+/+++++++/////:::::---:::///+oosssyyyyyssssssoooo/:::-::+/+ssoo+++/////////////////////-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+`--------------------:++++osyyy+///+++oooooossssyyyyyyyssso+/:----::/+oossyhhhhhyysooooo+++ooo+++:-:yyyso+++o+////////////////////+-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+````````````````````-++///+syhy+///+ooo+++oossyyyyyyyhhhyyso+::---::/ooossyyysysdyyyssooo++++oo++/-:osoo++ooos/::::::::::::::::::::-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+````````````````````:+/////+shs////++//++osssshysmoyosyysooo+//::://+oooosso//sohsoo+syso+++/++++/:-:o+++++oos+-.....................`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+--------------------:+//////oyo////////++osso/+osso++oso++/++//::///osoosoo+/://++//++ooo++/////++/--++ooo++os+::::::::::::::::::::-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+--------------------:+///://oo+///::::///+++++/+++++++++///++//::///+ooo+++///////++++++++//////++/:-/oo++++os+--------------------..`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+::::::::::::::::::::////////++////:::::///////////////////++///::///+ooooo+/////:://///////////++++/::oso++/+s/......................`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+/--------------------://::/o+///////////////:::::://///////////:://+++++o++///:::::://///:::///+++//::+ooo+++o:....................-.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+s````````````````````://::///////////::::::::::::://:://///////:://+oo++++++///:::::::::::::://++////:+++oso+o:--------------------:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y....................-//:///////////::::::::::::::/::://////////://+o++++++//////:::::::::::://++///+/+/oyyo+o:---------------------.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y-...................-//://:/+//////::::::::::::::::::://+//+//////+oooo++/////:::::::::::::://+///++++syyo+++---------------------:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y.```````````````````.//://::++/////:::::::::::::::::::/+++////::://+osooo/:::::::::::::::::://++/++++yyso+++/:::::::::::::::::::--:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:.```````````````````:/::///+++////:::::::::::::::::::/++////:--::/+ooo++o/::::::::::::::::://++/+++++++oo+:--------------------.-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:o--------------------://:::/o+////::::::::::::::::::://////:----::/+++++++/::::::::::::::://+++/+++++/+++:```````````````````-:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:sy--------------------:/:::/++/////:::::::-:--::::::://+///::::::/++++o++oo+:::::::::::::///+++/+++oo+++:-------------------+y:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shy/-------------------:/:///++///::::::::----:-:-:::/++oo+//::///++ooooooo+/::::::::::::///++//++++++/--------------------/hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhho-:::::::::::::::::::::::/+////:::::::-------:::::/+++////+++++oooooo++/:::::---:::::///++////--..------------------.`-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy`.-:::::::::::::::::.`..-/+///:::::::--------:::::/+++//////++ooooo++///::::::::::::///+++//--.`.----------------:.``-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy```o::::::::::::::::.``.--+////::::::-------::////++//////://///+++++++///:::::::::///++++/:`````...............ss.``-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy```yd---------------..---.://///:::::------::////////:::::::::///////+++++/::::::::///++++/....................-do.``-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy```yd..```````````````````.//////:::::::--:://+////++++++++++oooooooossso+/:-:::///////++/:````````````````````+ho.``-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+ooooooo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy```yd.....................-:///////:::::--::/+ooooo++/////++///////++o+///::::::///////++/:...................`sho.``-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+ooooooo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy```yd.-::::::::::::::::::::/:///////:::::--://////////://////////////////:::::////////++/:/````````````````````yho.``-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+ooooooo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy```yd.-//////////////////////:///////:/::-:::::/://:////+oooooo+////:///:::::::///////+/:+/````````````````````yho.``-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+ooooooo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy```yd..////////////////////////////////:/::::::://:::://+++ooo+///::::::::::::///////+///+/````````````````````hho.``-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+ooooooo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy```yd..///////////////////////++/////////::::::::::::::///::////////:::::://///////+++/+++:````````````````````hho.``-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy```yd..//////////////////////:/++////////:::/::::::::::::::-:::://////////////////+++/++++:````````````````````hho.``-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy```yd..///////////////////////://++////////:::://:/::::::--:-::::///////////////++++++++++:````````````````````dho.``-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy```yd..+//////////////////////:::/++++///////:://///::::::::::::::////++/+++/+++oo++++++++:``````````````````-:dho.``-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy```yd..///////////////////////:::://+++++/////////////::::://:::////+++++oo++oooo+++++++o+:````````````````-+shdho.``-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy```yd..::.-.-/+////////////////::::://++o+oo++++++/+///////::///+/++ooooooossoo+++++++++++:```````````````+hssddho.``-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy```yd..::`-..-h+//////////////:::::::://++ossoo+ooooooo+++++++ooosssooossysso+++++++++++++:`````````.```-.hdssddho.``-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy```yd..::`-..-do:::::::::::///::::::::::///+oossssoosssssssssssssssooossso++++++++++++++++:````````:.```-.hdssddho.``-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy```yd..::`-..-do:-`````````:///:::::::::::///++ossssssooosssooooosoosss++++++++//////+++++:`````-/`/.```-.hdssddho.``-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy```yd..::`-..-do:-.:`````.`:///::::::::::::::///++++oooooooo+++++++++++++++++////////+++++:````+d+`/.```-.hdssddho.``-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy```yd..::`-..-do:-./````.//////::::::::::::::::::/:://///////////////////+////////////++++/--:-dd+`/.```-.hdssddho.``-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy```yd..::`-..-do:-./``.-/+++///:::::::::::::::::::::::::::::::::::::://///////////////++++//++:ddyo+-.``-.hdssddho.``-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy```yd..::`-..:ds/-./.:/+++++///::::::----:::::::::::----------:::::::://///////:://////+++//ooooymNmo/:.-.hdssddho.``-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy```yd..::.-:/ddmho:+++///+++///::::-----:--::::::::::::-------:::::::::/:::::::::://///+++++sssssydms//:/-sdhyhdhs.``-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy```yd..:::::/ddso+++/////++////:::::--------:::::::::::::::::::::::::::::::::::::::////++++ssooooshm/::::::mmmhmmds:`-+hy:`-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhy``:hd+::::---/ds+/////////+/////:::::--------::::-:-----:::::::::::::::::::::::::::////+++oooooooyms--:::::mmmmmmmmmyoshh+.-:.`:.--.o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``.+y:shhhh/odmmd:-------+h+///////////////::::::-----------------------::::::::::::::::::::::////+++oooo+osdy-------ommmmmmmmmmmmmmmds/--:----o:``-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:`-.`::``-shyhddmmmmmmmmd--......+y/:::::////////:::::::--------------------------------:-:---:::::::////+++o+++oohh-----.--mmmmmmmmmmmmmmmmmm/::::::os:.`-+ooo:-.-.`````````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````+o.:.---::+hmmmmmmmmmmmmddmmh-.......+s/::::::://///::::::::-------------------------------------:::::::///++++++++syh--.-....ymmmmmmmmmmmmmmmmmd-::::::yyyso+oooo++//:-.```````/oo+oooosoo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.`````:++/:::::-:dmmmmmmmmdddddddmmh-......./s/::::::://///::::::::-----------------------------------::::::::////+++++ooyy-.......ommmmmmmmmmmmmmmmmmh-:::::/yhsoooooooooooosoo+//:-./oo+ooooooo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++/-.``.-:/+ss/:-:---ommmmmmmmmdddddddddd:.......:s+:::::::///::::::::::--------------------------------::::::::://///+++oooho-.......ommmmmmmmmmmmmmmmmmmy-::::::yyo++++++++++++oooooosssssooooooooo+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````-/+o++++//:/+ooooosss------:mmmmmmmmmmmddddddmdd/........oo::::::://:::::::::::----------:---------------------:::::::::////++ssyh:........smmmmmmmmmmmmmmmmmmmmy--::--:yy++++///++++++++++oooooossssssssso+o++//-.`````````````````````
                +++++++++++++++++++++++++++++++++:.`````:/+++++oooo+++++ooosy:------hmmmmmmmmmmmddddddddds......../s/:::::://::::::::::::--------:::----:-:---------::::::::::::///+syhh+........-hmmmmmmmmmmmmmmmmmmmmmh-------sy+////////++++++++++ooooooooosssssooo+//-.`````````````````````
                +++++++++++++++++++++++++++++++++:..-:/+oooo+++++++++++++++oy/------smmmmdddmmmmmdddddddddh:``.....-+o/::::::::::::::::::-:-:-:-::::::::::------:::--:::::::::://+oyyy+........./dmmmmmmmmmmmmmmmmmmmmmmh.-----.+y+/////////++++++++++++++ooooooooossoo+/-.`````````````````````
                +++++++++++++++++++++++++++++++++++oooo+++++++/////////////+y+.---.-/mmdddddmmmmmdddddddddddo........-+so/:::::::::::::::--::-:::::::::::::::::::::---::::////+ooyyo:.........-ymmmmmmmmmmmmmmmmmmmmmmmmm-..----:ys////////++++++++++++++++++++++oooosso+:-`````````````````````
                ++++++++++++++++++++++++++++++ooo+++++++++//////////////////so......:mmmmdddmmmmdddddddddddddh/.`.......:oss+/::::::::::::::::::::::::::::::::::::---::://++osyyo/..........-sdmmmmmmmmmmdmmmmmmmmmmmmmmm/.......sy/////////+//++/++++/++/+++++++++oooooso/-.```````````````````
                +++++++++++++++++++++++++++oooo+++++////////////////////////so......:mdddddddddddddddddddddddddy:`..`......:+syo+/::::::::---::::::::::::::::::::---::/++osss+:...........:sdmmmmmmmmmmmmmmmmmmmmmmmmddmmo.......+y+////////////////////////////++++++ooosso:...................`
                +++++++++++++++++++++++++oo+++++++//////////////////////:///so......-mdddddddddddddddddddddddddddy:...........-:+oso+/::::---:::::::::::::::::::::::/+oso/:............./ydmmmmmmmmmmmmmmmmmmmmmmmmmdddmmd.......-so///////////////////////////////++++ooooos+:.................`
                +++++++++++++++++++++++o+++++++/////////////////////////:///s+......-ddddddddddddddddddddddddddddddy/.`............-/+oo+/:---:::::::::::::::::::/+oo/:............../shdmmmmmmmmmmmmmddmmmmmmmmmmmdddmmmm/.......os////////:::::://////////////////++++oooooso/::::::::::::::::`
                +++++++++++++++++++++++++++//////////////////////////////://s/......-ddddddddddddddddddddddddddddddddhs/-...............:+o+/:::::::::::::----:+s+:..............-/shddmmmmmmmmmmmmddddddmmmmmmmmmddddmmmmh.......:s+//:/:::::::::::::::/:///////////+++++ooooss+///////////////.
                ++++++++++++++++++++++++///////////:://////////////:/::::://y-......-dddddddddddddddddddddddddddddddddddhs+:.`...........`.:+o+//::::::-----:+o/-............-/ohddmddmmmmmmdddddddddddddmmmmmmmmddddmmmmmm:.......ss:::::::::::::::::::::::::////////+++++oooosso//////////////.
                ::::::::::::::::/+++++/////////::::::::::::/::::::::::::::/+y.......-ddddmdddddddddddddddddddddddddddddddddhhs+:.`.........`.-+o++//:::::::/o+............:+yhdddmdddddddddddddddddhhhhhhdhhhhhdddddmmmmmmdy.......:s+::::::::::::::::::::::::::://////+++++oooosso+++++++++++++.
                ..............-/++++///////:::::::::::::::::::::::::::::::/os.......:ddddddddddddddddddddddddddddddddddddddddddhhs/-........```-+so+//::::+o:..`.......:shddddddmdddds+++ody/////dh:::/++ms::::sddddmmmmmmdd:.......os:::::::::::::::::::::::::::///////+++++oooosoo+++++++++++o.
                .............-++++++/////:::::::::::::::::::::::::::::::::/s+`......+ddddddddddddddddddddddddddddddddddddddddddddddhy/-``.....``.:oso+//+o+.```......:ydddddddmmdddddh::::ho::::-sy-::+::dh-:::+ddmmmmmmmdddy.......-s+::::::::::::::::::::::::::://////+++++ooooossoo+++++++++o.
                :::::::::::::+++++/////:::::::::::::::::::::::::::::::::::/y:......`yddddddddddddddddddddddddddddddddddddddmmdddddddddh+.``....```./ssoso:..........sdddddddmmmdddddddy-::+/:-+:::o-:-+--hd:::::ddmmmmmmmdddm/.......+y/::::::::::::::::::::::::::///////+++++oooossso++++++++++.
                +++++++++++++++++//////::::::::::::::::::::::---::::::::::oy.......-dddddddddddddhddddddddddddddddddddddddddddmdddddddddy-`.......``./o+.`........-yddddddmmmmddddddddd+:::::-y+::::::+--oy::::/mdmmmmmmdddddd-.......ss::::::::::::::::::::::::::://////++++++oooossso+++++++++.
                ++++++++++++++++//////:::::::-------------------:--::::::/s+`.....`+dddddddddddy++dddddddddddddddddhhhhyysssshmmmddddddddh/``......```.```........hdddddmmmmdddddddddddd/::::-hh:::::++::::://ohmdmmmmmmddddddy.......:y+::::::::::::::::::::::::::///////++++++oooossso++++++++.
                ++++++++++++++++/////::::::::----------------:-------::::/y-.......hdddddddddh+:-hdddddddhhhyso+////++osyyhddddmmmmdddddddd:`.........`.........`sddddmmmmmdddddddddddddysssssdhyyysyhyyyysshssyydmmmmmdddddmdd/.......+y:::::::::::::::::::::::::::///////++++++ooosssso++++++o.
                ////////++++++++/////:::::::::-----------------------::::os`....../dddddddddd::::/ossso++/::://osyhhddddddddddddmmmmmddddddh..........`.........:dddmmmmmddddddddmmdddyo+ooy/od++sd+sd/oyso+hososddmmmddddddmddh........so:::::::::::::::::::::::::::://////+++++oooosssoo++++++.
                +++++++++++++///////::::::::::-----------------------:::/y:`......ydddddddddd/::::::::://+syhdddddddddddddddddddddmmmmmddddd+`.................`oddmmmdddddddddmmmdddddsdyhdyhdshsdsshssshoyoy+s/ddmmmdddddddddds.......:y/:::::::::::::::::::::::::::///////++++++ooosssoo+++++.
                +++++++++++++//////:::::::::::------------------------::+s``....`/ddddddddddddysooosyyhddddddddddddddddddddddddddmmmmmmmddddy`.................`sdmmddddddddmmmmmmddmdddddddddd/h/h+s+ohohsysdyhymdmmdddddddddddd+.......os:::::::::::::::::::::::::::////////+++++oooossso+oooo.
                +////+++++++///////:::::::::::------------------------:/s:``.....hdddddddddddddddddddddddddddddddddddddddddddmmmmmmdmmmmmmmdd.................-:ymdddddddmmmmmmmddddddddddddddddhddddddddddddmdmdddmdddddddddddddd-......-y+:::::::::::::::::::::::::://///////+++++oooosssooooo.
                ////+++++++//////::::::::::::::-----------------------:+s``....`+dddddddddddddddddddddddddddddddddddddddddmmmmmmmmmmmmmmmmmmmo++ooooossssyyhhddmddddmmmmmmmmmddddddddddddddddddddddddddddddddmddddddddddddddddddddy......./y/::::::::::::::::::::::::://////////++++oooosssso+++.
                ////++++++///////:::::::::::::::---------------------:/s:``.....hddddddddddddddddddddddddddddddddddmmdmddmmmmdmddddddddddddddddddmmdmdmmmmmmmmmmmmmmmmmmmmddddddddddddddddddddddddddddddddddddddddddddddddddddddddd+`......oo:::::::::::::::::::::::::://///////+++++oooossss+++.
                +++++++++////////:::::::::::::::---------------------:+o```...`oddddddddddddddddddddddddddddddddddddmmdmmmmdddddddddddddddddmmmmmmmmmmmmmmmmmmmmmmmmmmddddddddddddddddddddddddddddddmddddddddddddddddddddddddddddddd:......-y+///::::::::::::::::::::::://///////+++++ooooossooo.
                +++++++++///////:::::::::::::::---------------------:/s-```..`:ddddddddddddddddddddddddddddddddddddddddddddddddddddddddddmmmmdddmmmmmmmmmmmmmmmmmdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddh......`/y///::::::::::::::::::::::://///////++++++oooosso++.
                ++++++++////////:::::::::::::--:-------------------::o+````...hdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddmmmdddmdmdddddddddddddddddddddddddddddddds`......so+//::::::::::::::::::::::///////////++++oooososoo.
                +++++++//////////:::::::::::::::-----------------:::+s.```..`sddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddmmmmmmmmmmmmmdmdmmmddddddddddddddddddddddddddddddddd/`.....-y+o//:::::::::::::::::////://////////+++++ooosssoo.
                ++++++////////:/:::::::::::::::-----:----------:::::s:```..`:dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddmmddddddmddmmmdmdddmddddddddddddddddddddddddddddddddddd-......+s++//::::::::::::::::::::///////////++++++oooosso.
)" << endl;
}

/*
//
// This is the start of a main function that Ben has created
//
#include "Player.hpp"
#include<iostream>
using namespace std;

void menu();

int main() {
	bool tf = 1;
	string menuChoice;
	//percentile_scoring ps;
	//ps.readinfile("train_data.csv");

	cout << "-----Welcome to the NBA Draft predictor-----" << endl;
	menu();
	getline(cin,menuChoice);
	do
	{

		switch(menuChoice[0])
		{

			case '1':
			{
				break;
			}
			case'9':
			{
				cout << "Exiting" << endl;
				//call desctructor here
				tf = false;
				break;
			}
		}
		if(tf == false)
		{
			break;
		}
		menu();
		getline(cin,menuChoice);


	}while(menuChoice[0] != '9' || tf == true);

}


void menu()
{
	cout <<"-----Please input the corresponding number for your selection and press 'Enter'-----" << endl;
	cout <<"1. ..." << endl;
	cout <<"2. ..." << endl;
	cout <<"3. ..." << endl;
	cout <<"4. ..." << endl;
	cout <<"5. ..." << endl;
	cout <<"6. ..." << endl;

}
*/
